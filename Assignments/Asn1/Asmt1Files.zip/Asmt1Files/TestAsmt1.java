
public class TestAsmt1 {

	public static void main(String[] args) {
		boolean testPassed = true;
		GridBoard board = null;
		Snake theSnake = null;
		String[][] matrix = {{"empty", "empty", "apple", "empty"},
				     {"empty", "rock", "empty", "apple"},
				     {"scissors", "empty", "empty", "empty"}};
		String[][] invMatrix = {{"empty", "apple", "empty", "empty"},
					{"apple", "empty", "rock", "empty"},
					{"empty", "empty", "empty", "scissors"}};
		
		System.out.println("Tests for classes GridPosition, GridBoard, and Snake");
		System.out.println("----------------------------------------------------\n"); 

		// Test 1. Test methods from class GridPosition
		try {
			GridPosition pos = new GridPosition(5,7);
			if ((pos.getRow() != 5) || (pos.getCol() != 7)) testPassed = false;
			pos.setRow(1);
			pos.setCol(2);
			if ((pos.getRow() != 1) || (pos.getCol() != 2)) testPassed = false;
			GridPosition pos2 = new GridPosition(1,2);
			GridPosition pos3 = new GridPosition(1,3);
			
			if (!pos.equals(pos2)) testPassed = false;
			if (pos.equals(pos3)) testPassed = false;
			if (testPassed)
				System.out.println("Test 1 passed");
			else
				System.out.println("Test 1 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 1 failed: Null pointer exception error");
			else System.out.println("Test 1 failed: The program crashed with this error "+e.getMessage());
		}

		// Test 2. Constructor for class GridBoard
		try {
			testPassed = true;
			board = new GridBoard("testboard.txt");
			// Check that the file testboard.txt was read correctly
			for (int i = 0; i < 3; ++i)
				for (int j = 0; j < 4; ++j)
					if (!board.getObject(i,j).equals(matrix[i][j])) testPassed = false;

			if (testPassed)
				System.out.println("Test 2 passed");
			else
				System.out.println("Test 2 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 2 failed: Null pointer exception error");
			else System.out.println("Test 2 failed: The program crashed with this error "+e.getMessage());
		}

		// Test 3. Test methods setObject, getNumCols, and getNumRows of class GameBoard
		try {
			testPassed = true;
			board.setObject(2,3,"scissors");
			String s = board.getObject(2,3);
			if (!s.equals("scissors")) testPassed = false;
			if (board.getNumCols() != 4 || board.getNumRows() != 3) testPassed = false;
			if (testPassed)
				System.out.println("Test 3 passed");
			else
				System.out.println("Test 3 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 3 failed: Null pointer exception error");
			else System.out.println("Test 3 failed: The program crashed with this error "+e.getMessage());
		}

		// Test 4. Test method getSnake of class GameBoard and methods getLength and snakeGridPosition of class Snake
		try {
			testPassed = true;
			GridPosition pos;
			theSnake = board.getSnake();
			if (theSnake.getLength() != 1) testPassed = false;
			pos = theSnake.getGridPosition(0);
			if (pos.getRow() != 2 || pos.getCol() != 2) testPassed = false;
			if (testPassed)
				System.out.println("Test 4 passed");
			else
				System.out.println("Test 4 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 4 failed: Null pointer exception error");
			else System.out.println("Test 4 failed: The program crashed with this error "+e.getMessage());
		}
		
		// Test 5. Test constructor for class Snake and methods getGridPosition, and shrink
		try {
			testPassed = true;
			theSnake = new Snake(4,7);
			if (!theSnake.getGridPosition(0).equals(new GridPosition(4,7))) testPassed = false;
			if (theSnake.getGridPosition(-1) != null || theSnake.getGridPosition(1) != null)
				testPassed = false;
			theSnake.shrink();
			if (theSnake.getLength() != 0) testPassed = false;
			if (testPassed)
				System.out.println("Test 5 passed");
			else
				System.out.println("Test 5 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 5 failed: Null pointer exception error");
			else System.out.println("Test 5 failed: The program crashed with this error "+e.getMessage());
		}
		
		// Test 6. Test newHeadGridPosition, snakeGridPosition
		try {
			testPassed = true;
			theSnake = new Snake(1,1);
			GridPosition up = new GridPosition(0,1);
			GridPosition down = new GridPosition(2,1);
			GridPosition right = new GridPosition(1,2);
			GridPosition left = new GridPosition(1,0);
			if (!theSnake.newHeadGridPosition("up").equals(up)) testPassed = false;
			if (!theSnake.newHeadGridPosition("down").equals(down)) testPassed = false;
			if (!theSnake.newHeadGridPosition("left").equals(left)) testPassed = false;
			if (!theSnake.newHeadGridPosition("right").equals(right)) testPassed = false;
			if (!theSnake.snakeGridPosition(new GridPosition(1,1))) testPassed = false;
			if (theSnake.snakeGridPosition(new GridPosition(0,1))) testPassed = false;
			if (testPassed)
				System.out.println("Test 6 passed");
			else
				System.out.println("Test 6 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 6 failed: Null pointer exception error");
			else System.out.println("Test 6 failed: The program crashed with this error "+e.getMessage());
		}
		
		// Test 7. Test method moveSnake
		try {
			testPassed = true;
			theSnake = new Snake(2,2);
			theSnake.moveSnake("right");
			if (!theSnake.snakeGridPosition(new GridPosition(2,3))) testPassed = false;
			if (theSnake.snakeGridPosition(new GridPosition(2,2))) testPassed = false;
			theSnake.moveSnake("up");
			if (!theSnake.snakeGridPosition(new GridPosition(1,3))) testPassed = false;
			if (theSnake.getLength() != 1) testPassed = false;
			theSnake.moveSnake("left");
			if (!theSnake.getGridPosition(0).equals(new GridPosition(1,2))) testPassed = false;
			theSnake.moveSnake("down");
			if (!theSnake.getGridPosition(0).equals(new GridPosition(2,2))) testPassed = false;			
			if (testPassed)
				System.out.println("Test 7 passed");
			else
				System.out.println("Test 7 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 7 failed: Null pointer exception error");
			else System.out.println("Test 7 failed: The program crashed with this error "+e.getMessage());
		}
		
		// Test growSnake 
		try {
			testPassed = true;
			theSnake = new Snake(1,1);
			theSnake.growSnake("right");
			theSnake.growSnake("down");
			theSnake.growSnake("down");
			theSnake.growSnake("left");
			if (theSnake.getLength() != 5) testPassed = false;
			if (!theSnake.snakeGridPosition(new GridPosition(1,2))) testPassed = false;
			if (!theSnake.snakeGridPosition(new GridPosition(2,2))) testPassed = false;
			if (!theSnake.snakeGridPosition(new GridPosition(3,2))) testPassed = false;
			if (!theSnake.snakeGridPosition(new GridPosition(3,1))) testPassed = false;			
			if (testPassed)
				System.out.println("Test 8 passed");
			else
				System.out.println("Test 8 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 8 failed: Null pointer exception error");
			else System.out.println("Test 8 failed: The program crashed with this error "+e.getMessage());
		}
		
		// Test increaseArraySize, growSnake 
		try {
			testPassed = true;
			theSnake.growSnake("up");	
			if (theSnake.getLength() != 6) testPassed = false;
			theSnake.growSnake("left");
			if (!theSnake.getGridPosition(0).equals(new GridPosition(2,0))) testPassed = false;
			if (testPassed)
				System.out.println("Test 9 passed");
			else
				System.out.println("Test 9 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 9 failed: Null pointer exception error");
			else System.out.println("Test 9 failed: The program crashed with this error "+e.getMessage());
		}
		
		// Test moveSnake 
		try {
			testPassed = true;
			theSnake.moveSnake("down");
			theSnake.moveSnake("down");
			theSnake.moveSnake("right");
			if (!theSnake.getGridPosition(0).equals(new GridPosition(4,1))) testPassed = false;
			if (!theSnake.getGridPosition(1).equals(new GridPosition(4,0))) testPassed = false;
			if (!theSnake.getGridPosition(2).equals(new GridPosition(3,0))) testPassed = false;
			if (!theSnake.getGridPosition(3).equals(new GridPosition(2,0))) testPassed = false;
			if (!theSnake.getGridPosition(4).equals(new GridPosition(2,1))) testPassed = false;
			if (!theSnake.getGridPosition(5).equals(new GridPosition(3,1))) testPassed = false;
			if (!theSnake.getGridPosition(6).equals(new GridPosition(3,2))) testPassed = false;
			if (testPassed)
				System.out.println("Test 10 passed");
			else
				System.out.println("Test 10 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 10 failed: Null pointer exception error");
			else System.out.println("Test 10 failed: The program crashed with this error "+e.getMessage());
		}
		
		// Test methods invertGrid and invertSnake 
		try {
			int[] row = {1,1,2,2};
			int[] col = {1,0,0,1};
			testPassed = true;
			board = new GridBoard("testboard.txt");
			theSnake = board.getSnake();
			theSnake.growSnake("right");
			theSnake.growSnake("up");
			theSnake.growSnake("left");
			
			board.invertGrid();
			// Check that the file testboard.txt was inverted correctly
			for (int i = 0; i < 3; ++i)
				for (int j = 0; j < 4; ++j)
					if (!board.getObject(i,j).equals(invMatrix[i][j])) testPassed = false;
					
			for (int i = 0; i < 4; ++i) {
				GridPosition p = theSnake.getGridPosition(i);
				if ((p.getRow() != row[i]) || (p.getCol() != col[i])) testPassed = false;
			}
			if (testPassed)
				System.out.println("Test 11 passed");
			else
				System.out.println("Test 11 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 11 failed: Null pointer exception error");
			else System.out.println("Test 11 failed: The program crashed with this error "+e.getMessage());
		}	
		
		// Test method increaseArraySize 
		try {
			testPassed = true;
			theSnake = new Snake(1,1);
			GridPosition[] snakeBody = theSnake.getSnakeBody();	
			if (snakeBody.length != 5) testPassed = false;
								
			for (int i = 0; i < 5; ++i)
				theSnake.growSnake("right");
			snakeBody = theSnake.getSnakeBody();	

			if (snakeBody.length != 10) testPassed = false;
			
			for (int i = 0; i < 6; ++i)
				theSnake.growSnake("right");
		
			snakeBody = theSnake.getSnakeBody();	
			if (snakeBody.length != 18) testPassed = false;
										
			if (testPassed)
				System.out.println("Test 12 passed");
			else
				System.out.println("Test 12 failed");
		} catch (Exception e) {
			if (e.getMessage() == "null")
				System.out.println("Test 12 failed: Null pointer exception error");
			else System.out.println("Test 12 failed: The program crashed with this error "+e.getMessage());
		}				
	}

}
