
public class FileObjectException extends Exception{

	public FileObjectException (String mssg){
		super(mssg);
	}
}
