import java.util.Comparator;

public class NameComparator implements Comparator<TreeNode<Archive>> {

	public int compare(TreeNode<Archive> obj1, TreeNode<Archive> obj2) {
		return obj1.getData().getName().compareTo(obj2.getData().getName());
	}
	
}
